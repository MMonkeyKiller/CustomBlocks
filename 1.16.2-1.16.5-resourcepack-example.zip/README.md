# Resourcepack Format

## note_block.json

_Block/Item Model_\
Path: `blockstates/note_block.json`

```json
{
  "instrument=[noteblock instrument],note=[Note 0 for decoration only],powered=false[prevent issues]": {
    "model": "block/note_block [for decoration]"
  },
  "instrument=[noteblock instrument],note=[Note 0 for decoration only],powered=true[prevent issues]": {
    "model": "block/note_block [for decoration]"
  }
}
```

## paper.json

_Recomended for custom block item models_\
Path: `models/item/paper.json` **It needs to be a vanilla minecraft item!**

```json
{
  "predicate": {
    "custom_model_data": 1001
  },
  "model": "block/example"
}
```

```yaml
custom_model_data: For multiple item models in a single item
model: Block model (parent cube_all contains block & item model)
```